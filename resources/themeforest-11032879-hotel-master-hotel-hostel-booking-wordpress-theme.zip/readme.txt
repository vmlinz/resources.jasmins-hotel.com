This version is ‘2.06’
============================================================

Theme’s instruction is in the folder ‘document/instruction’. Please open that folder and open the file ‘index.html’ with your browsers.

============================================================

==v2.06== 15/02/2016
- add revision feature
	gdlr-revision.php
	functions.php

==v2.05== 02/02/2016
- fix shortcode spacing
	include/plugin/shortcode-generator.php

-gdlr-hotel	
-fix coupon display after the contact page
	include/gdlr-booking-item.php
	
-gdlr-hostel
-fix coupon display after the contact page
	include/gdlrs-booking-item.php

==v2.04== 23/12/2015
fix date displaying bug / fix date translation
 - gdlr hotel plugin
 	gdlr-hotel.js file
 - gdlr hostel plugin
  	gdlr-hotel.js file

==v2.03== 20/12/2015
fix bug when night num more than 9
LMS Russian translation by : Vlada
	gdlr-hotel/gdlr-hotel.js
	gdlr-hotel/include/gdlr-reservation-bar.php
	gdlr-hotel/include/page-builder-sync.php
	
	gdlr-hostel/gdlr-hotel.js
	gdlr-hostel/include/gdlrs-reservation-bar.php
	gdlr-hostel/include/gdlrs-page-builder-sync.php
	
- wp 4.4 compatibility
	framework/javascirpt/gdlr-sidebar-generator.js
	include/function-blog-item.php
	
- update master slider

==v2.02== 24/10/2015
- update master slider

PLUGIN 
- fix authorize payment
	gdlr-hotel/framework/plugin-option.php
	gdlr-hotel/include/gdlrs-authorize-payment.php
	
	gdlr-hostel/framework/plugin-option.php
	gdlr-hostel/include/gdlrs-authorize-payment.php

- fix price calculation on special season ( * with date range )
	gdlr-hotel/include/gdlr-price-calculation.php
	gdlr-hotel/gdlr-hotel.js
	gdlr-hostel/include/gdlr-price-calculation.php
	gdlr-hostel/gdlr-hotel.js

==v2.01== 26/08/2015
- add max num option (bug fixed)
	gdlr-hotel/framework/room-option.php
- fix button shortcode
	gdlr-shortcode plugin

==v2.00== 24/08/2015
- shortcode fix
	==gdlr-shortcode plugin
	include/function/gdlr-utility.php
- hostel fully supported
- add compatibility with wpml
- fix multiple room selection
- change adult number if max people is less than 2
- validate check-in check-out date
- option to block booking date
- unlimited seasonal pricing
- new services, facilities manager
- additional chargeable services
	== hotel plugin’s files
	framework/service-option.php
	framework/gdlr-transaction.php
	framework/transaction-style.css
	include/gdlr-booking-item.php
	include/gdlr-reservation-bar.php
	include/gdlr-price-calculation.php
	include/gdlr-room-option.php
	include/gdlr-room-item.php
	gdlr-hotel.js

	== theme’s files
	include/gdlr-admin-option.php
	include/gdlr-page-builder-option.php
	include/function/gdlr-page-item.php
	include/widget folder
	framework/function/gdlr-admin-panel-html.php
	framework/stylesheet/gdlr-admin-panel-html.css
	framework/javascript/gdlr-admin-panel-html.js

==v1.11== 22/06/2015
- fix multiple room available booking
	gdlr-hotel plugin

==v1.10== 11/05/2015
- update localization ability for date-picker
- fix shortcode in room page
	gdlr-hotel plugin
	
- dark color for dropdown option
	include/gdlr-admin-option.php

- single room responsive
	stylesheet/style-responsive.css
	
- xss
	include/plugin/class-tgm-plugin-activation.php

==v1.00== 10/04/2015
* initial released 